var app =angular.module("myapp" , []);
app.controller("myctrl" ,function($scope){
$scope.users=[{id:1,firstname:"vicky",lastname:"chauhan", email:"vicky@gmail.com", phoneno:7508222083 }


];
$scope.id = 1;
$scope.add=function(){
	$scope.id++;
	$scope.users.push({id:$scope.id, firstname:$scope.name, lastname:$scope.last, email:$scope.email, phoneno:$scope.phone });
console.log($scope.users);
$scope.name=" ";
$scope.last=" ";
$scope.email=" ";
$scope.phone=" ";
}
$scope.delete=function(id){
	$scope.users.forEach(function(usr,index){
		//console.log('user   ',usr.id,'id', id);
		if(usr.id==id){
			 $scope.users.splice(index, 1);
		}

	});

	//$scope.users.pop({firstname:$scope.name, lastname:$scope.last, email:$scope.email, phoneno:$scope.phone })
}



});

