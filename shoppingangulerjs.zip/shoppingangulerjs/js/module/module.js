var app =angular.module('myapp', ['ngRoute']);
app.config(function($routeProvider) {
    $routeProvider.when('/login', {
        templateUrl: 'js/views/login.html',
        controller: 'indexCtrl'
    }).
        when('/home', {
        templateUrl: 'js/views/home.html',
        controller: 'indexCtrl'
    }).
        when('/view', {
        templateUrl: 'js/views/view.html',
        controller: 'indexCtrl'
    }).
        when('/signup', {
        templateUrl: 'js/views/signup.html',
        controller: 'indexCtrl'
    }).
        when('/contact', {
        templateUrl: 'js/views/contact.html',
        controller: 'indexCtrl'
    }).
      otherwise({
        redirectTo: '/home' 
      });

});
