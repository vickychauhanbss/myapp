var express = require('express');
var router = express.Router();
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;
var User = require('../models/usermodel');
//route 
// router.get('/', ensureAuthenticated,function(req, res){
// 	res.render('index');
// });
//authenticated page
router.get('/', ensureAuthenticated, function(req, res){
	res.render('index');
});
router.get('/profile',ensureAuthenticated, function(req, res){
	res.render('profile');
});
function ensureAuthenticated(req, res, next){
	if(req.isAuthenticated()){
		return next();
	} else {
		//req.flash('error_msg','You are not logged in');
		res.redirect('/login');
	}
}
// Register
router.get('/register', function(req, res){
	res.render('register');
});

// Login
router.get('/login', function(req, res){
	res.render('login');
});

// Register User
router.post('/register', function(req, res){
	var myuser=new User();
	myuser.local.name = req.body.name;
	myuser.local.email = req.body.email;
	myuser.local.username = req.body.username;
	myuser.local.password = req.body.password;
	
	User.findOne({'local.email':req.body.email},function(err,user){
		if(err){
			res.send(err);
		}else{
			if(!user){
				myuser.save(function(err,user){
					if(err){
						res.send(err)
					}else{
						 console.log(user);
						res.redirect('/login')
					}
				});
			}else{
				res.send("email is already register");
			}
		}
	});
	});

//googleOuthauthentication

// passport.use(new GoogleStrategy({
   
//   },
//   function(token, tokenSecret, profile, done) {
//       profile.oauth = { token: token, token_secret: tokenSecret };
//     done(null, profile);

//   }
// ));
   passport.use(new GoogleStrategy({

    clientID: '432437125796-66nvji2i0p2vqslcg0e80qr35dpjr8bt.apps.googleusercontent.com',
    clientSecret: '-HEqbUgIp1V3ae2PK3X8hBYr',
    callbackURL: "http://localhost:3000/auth/google/callback"

    },
    function(token, refreshToken, profile, done) {
        // User.findOne won't fire until we have all our data back from Google
	User.findOne({ 'google.id' : profile.id },function(err,user){
		if(err){
			return done(err);
		}else{
			if(user){
				return done(null,user);
			}else{
				var newuser= new User();
				    newuser.google.id    = profile.id;
                    newuser.google.token = token;
                    newuser.google.name  = profile.displayName;
                    newuser.google.email = profile.emails[0].value; 

			}
		}
	});

    }));


//**************************///
passport.use(new LocalStrategy(function(username, password, done) {
    User.findOne({'local.username': username }, function(err, user) {
      if (err) { return done(err); }
      if (!user) {
        return done(null, false, { message: 'Incorrect username.' });
      }
      if (user.local.password != password) {
        return done(null, false, { message: 'Incorrect password.' });
      }
      return done(null, user);
    });
  }));



//passport serialize user for their session
passport.serializeUser(function(user, done) {
  done(null, user);
});

passport.deserializeUser(function(user, done) {
  done(null, user);
});
//*********************************************

router.post('/login',
  passport.authenticate('local', {successRedirect:'/', failureRedirect:'/login'}),
   function(req, res) {
    res.redirect('/');
  });

//**********logout user*************************
router.get('/logout', function(req, res){
	req.logout();

	//req.flash('success_msg', 'You are logged out');

	res.redirect('/login');
});
//**********googleAut
router.get('/auth/google', passport.authenticate('google', { scope: [
       'https://www.googleapis.com/auth/plus.login',
       'https://www.googleapis.com/auth/plus.profile.emails.read'] 
}));
    // the callback after google has authenticated the user
router.get( '/auth/google/callback', 
    	passport.authenticate( 'google', { 
    		successRedirect: '/',
    		failureRedirect: '/login'
}));


module.exports = router;
