
var app = angular.module('myApp', []);
app.controller('MyCtrl', ['$scope', function ($scope) {
// $scope.id = 1;
$scope.teams=[{}];
$scope.addItems = function(){
//$scope.id++
$scope.teams.push({});
}
    
    
$scope.delete=function(id){
    $scope.teams.forEach(function(usr,index){
        //console.log('user   ',usr.id,'id', id);
        if(usr.id==id){
             $scope.teams.splice(index, 1);
        }

    })
    
    }
    $scope.inputCounter = 0;


}]);

 
app.directive('addInput', ['$compile', function ($compile) { 
    return {
        restrict: 'A',
        link: function (scope, element,  attrs) {
            
            element.find('button').bind('click', function () {
                
var input = angular.element('<div><input type="text" ng-model="field">
    <input type="text" ng-model="value">
    <input type="text" ng-model="fields">
    <input type="text" ng-model="values">
    <input type="button" value="remove" ng-click="delete(x.id)"></button> </div>');




               
                var compile = $compile(input)(scope);

                
                element.append(input);

               
                scope.inputCounter++;
            });
        }
    }
}]);

