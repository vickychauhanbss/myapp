var app=angular.module("myApp",['ngRoute','ngStorage','ui.bootstrap']);
app.config(function($routeProvider,$locationProvider){
	$routeProvider.
	when("/signup",{
	controller:"main",
	templateUrl:"/javascripts/view/signup.html"
	}).
	when("/login",{
	controller:"main",
	templateUrl:"/javascripts/view/login.html"
   }).
  when("/single",{
  controller:"profileController",
  templateUrl:"/javascripts/view/single.html"
   }).
  when("/profile",{
  controller:"profileController",
  templateUrl:"/javascripts/view/profile.html",
  resolve: {
        logedin:checkLoggedin
  }
  }).
    otherwise({
  redirectTo:'/login'
  }).
  when("/varifiEmail",{
  controller:"main",
  templateUrl:"/javascripts/view/varifyEmail.html"
   }).
  when("/list",{
  controller:"profileController",
  templateUrl:"/javascripts/view/list.html",
   resolve: {
        logedin:checkLoggedin
  }
  }).
    otherwise({
  redirectTo:'/login'
  }).
  when("/addusercart",{
  controller:"profileController",
  templateUrl:"/javascripts/view/addtocart.html",
   resolve: {
        logedin:checkLoggedin
  }
  }).
    otherwise({
  redirectTo:'/login'
  }).
   when("/mycheckout",{
  controller:"profileController",
  templateUrl:"/javascripts/view/checkout.html",
   resolve: {
        logedin:checkLoggedin
  }
  }).
    otherwise({
  redirectTo:'/login'
  }).
  when("/checkout",{
  controller:"profileController",
  templateUrl:"/javascripts/view/billing.html",
   resolve: {
        logedin:checkLoggedin
  }
  }).
    otherwise({
  redirectTo:'/login'
  }).
  when("/ordersummary",{
  controller:"profileController",
  templateUrl:"/javascripts/view/order.html",
   resolve: {
        logedin:checkLoggedin
  }
  }).
    otherwise({
  redirectTo:'/login'
  }).
  when("/paypal",{
  controller:"profileController",
  templateUrl:"/javascripts/view/paypal.html",
   resolve: {
        logedin:checkLoggedin
  }
  }).
    otherwise({
  redirectTo:'/login'
  });

  
   
 $locationProvider.html5Mode({
                 enabled: true,
                requireBase: false
              });
});
//************ image directive **************************

app.directive('fileModel', ['$parse', function ($parse) {
return {
    restrict: 'A',
    link: function(scope, element, attrs) {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                 modelSetter(scope, element[0].files[0]);
            });
        });
    }
};
}]);

// ************* paging ********************

   app.filter('startFrom', function () {
    return function (input, start) {
        if (input) {
            start = +start;
            return input.slice(start);
        }
        return [];
    };
});

//************ password match directive **************

app.directive('compareTo', [function() {
    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function(scope, element, attributes, ngModel) {
             
            ngModel.$validators.compareTo = function(modelValue) {
                return modelValue == scope.otherModelValue;
            };
 
            scope.$watch("otherModelValue", function() {
                ngModel.$validate();
            });
        }
    };
}]);

//**************** user login or not ***********************

var checkLoggedin = function($q, $timeout, $http, $location, $rootScope){
      // Initialize a new promise
      var deferred = $q.defer();
      $http.get('/users/loggedin').success(function(user){
        // Authenticated
        if(user !== '0'){
          //$timeout(deferred.resolve, 0);
        console.log("you are log in " + user);
          deferred.resolve();
             }
        // Not Authenticated
        else {
          $rootScope.message = 'You need to log in.';
          console.log("you are not log in " + user);
          deferred.reject();
         // $timeout(function(){deferred.reject();}, 0);
          $location.url('/login');
        }
      });
      return deferred.promise;
    };

//****************  add product and price controller *********************

app.controller("profileController",function($scope,$http,$location,$localStorage){
$scope.message="ADD PRODUCT";
//console.log($scope.myproduct);

 $http({
		method:"get",
		url:'/users/profile',
}).then(function successCallback(response){
   //alert("okk");
$scope.profieUser=response.data;
  console.log($scope.profieUser);
}, function errorCallback(res){
	console.log("error");
});

// $scope.saveproduct = function(){
// $http({
// method:"post",
// url:'users/product',
// data:{product:$scope.product,price:$scope.price},
// }).then(function successCallback(response){
//   console.log(response.data);
//   $location.path('/list');
// }, function errorCallback(res){
//   console.log("error");
// });

// }
//************ save product function ******************

$scope.saveproduct = function(){
var file = $scope.myFile;
var uploadUrl = "users/product";
var fd = new FormData();
    fd.append('product',$scope.product);
    fd.append('price',$scope.price);
    fd.append('file', file);
        console.log(fd);
  $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }).success(function (response){
             //console.log(response);
          //console.log(response);
          $location.path("/list");
        }).error(function(){
          console.log("error!!");
        }); 
    }


//************ logout function **************

$scope.logout=function(){

$http({
		method:"get",
		url:'/users/logout',
}).then(function successCallback(response){
	$location.path('/login');
}, function errorCallback(res){
	console.log("error");
});

}



//********* show cart page*****************

angular.element(document).ready(function(){
  $scope.error="";
$http({
  method: 'get',
    url: '/users/list/',
    }).then(function successCallback(response){
      if(response.data.error){
        $scope.error = response.data.error;
      }else 
        
       
        {
        
         $scope.myproduct=response.data;
         console.log($scope.myproduct);
         $scope.currentPage = 1;
  $scope.totalItems = $scope.myproduct.length;
  console.log($scope.myproduct.length);
  $scope.entryLimit = 6; 
  $scope.noOfpages = Math.ceil($scope.totalItems / $scope.entryLimit);

       // console.log($scope.myproduct);
      }
    });
  });
    

//********** product add to cart *******************

$scope.data=$localStorage.cart;
$scope.addcart=[];
$scope.addtocart = function(id){
  console.log(id);
   $http({
    method:'post',
    url:'/users/addusercart/'+id
    }).then(function successCallback(response){
    if(response.data.error){
      console.log(response.data.error);
    }
    else {
      
      $scope.user = response.data;
      //console.log($scope.user);
      //console.log(response.data);
        $scope.addcart.push($scope.user);
        $localStorage.cart = $scope.addcart;
      console.log($scope.addcart);
     // $location.path('/addusercart');
    }
   }, function errorCallback(response){
    console.log(response);
   });
};


  $scope.user2=$localStorage.user1;
$scope.checkout=function(){
  //console.log($scope.username,$scope.password);
    $http({
    method:"post",
    url:'/users/checkout',
    data:{fullname:$scope.fullname,email:$scope.email,address:$scope.address,city:$scope.city,state:$scope.state,country:$scope.country,mobile:$scope.mobile},
}).then(function successCallback(response){
    if(response.data.error){
      console.log(response.data.error);
    }
    else {
      
      $scope.user = response.data;
      $localStorage.user1 =$scope.user;
      console.log($scope.user);
      $location.path("/checkout");
  }
});
};



$scope.showcart =function(){
$location.path('/addusercart');
};





$scope.delete =function(index){
$scope.data.splice(index,1);
 };

 $scope.total = function() {
    var total = 0;
     angular.forEach($scope.data, function(item, key){
       total += parseInt(item.price * item.qty);
     });
     return total;
   };



$scope.backtocart = function() {
$location.path('/list');
};

$scope.order = function() {
$location.path('/ordersummary');
};
$scope.paypal = function() {
$location.path('/paypal');
};

$scope.check = function(){
$location.path('/mycheckout');
}
$scope.data1=$localStorage.cart1;
$scope.singleprofile = function(id) {
  console.log(id);
$http({
    method:'post',
    url:'/users/single/'+id

    }).then(function successCallback(response){
    if(response.data.error){
      console.log(response.data.error);
    }
    else {
      
      $scope.user = response.data;
      //console.log($scope.user);
      //console.log(response.data);
        //$scope.addcart.push($scope.user);
        $localStorage.cart1 = $scope.user;
     // console.log($scope.addcart);
      $location.path('/single');
    }
   }, function errorCallback(response){
    console.log(response);
   });
};


$scope.cash = function(){
  alert("your order book successfully \nproduct will be delivered with in 3 to 5 working days");
 
$location.path('/list');

}
});





app.controller("main",function($scope,$http,$location,$localStorage,$routeParams,$q,$rootScope){
		

	$scope.signup = function(){
 var uploadUrl = "/users/signup";
        var fd = new FormData();
        console.log(fd);
         var file = $scope.registration.user.myFile;
        fd.append('name',$scope.registration.user.name);
        fd.append('username',$scope.registration.user.username);
        fd.append('email',$scope.registration.user.email);
        fd.append('password',$scope.registration.user.password);
        fd.append('gender',$scope.registration.user.gender);
        fd.append('file', file);
        
        console.log(' $scope.gender ',$scope.gender);
        //JSON.stringify({name:$scope.registration.user.name,email:$scope.registration.user.email,password:$scope.registration.user.password, file:file})
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(){
           console.log("success!!");
          $location.path("/varifiEmail")
        })
        .error(function(){
          console.log("error!!");
        });
    };



$scope.mylogin=function(){
  console.log($scope.username,$scope.password);
		$http({
		method:"post",
		url:'/users/login',
		data:{username:$scope.username,password:$scope.password},
}).success(function(response){
           console.log("success!!");
          $location.path("/profile");
        }).error(function(response){
           console.log("error!!" ,response);
            $location.path("/login")
        });

}
});