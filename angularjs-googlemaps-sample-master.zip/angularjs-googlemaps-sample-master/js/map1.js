var app =angular.module("myapp" ,['google-maps']);

app.factory("mapFactory", function(){
var markerId =0;

function create(latitude ,longitude){

var marker={
options:{
  animaion: 1,
  labelAnchor:'37 -5',
  labelClass: 'labelMarker',
},
  latitude : latitude,
  longitude : longitude,
  id: ++markreId
};
return marker;
}

function invokeSuccessCallback(successCallback ,marker){

if(typeof successCallbck === 'function'){
 successCallback(marker);
}
};

function createByCroods (latitude , longitude , successCallback){

 var marker = create(latitude , longitude);
 invokeSuccessCallback(successCallback ,marker);	
};

function createByAddress(address ,successCallback){

var geocoder = new google.maps.Geocoder();
geocoder.geocode({'address' : addresss} ,function (results , status){

if (status === google.maps.GeocoderStatus.OK){

var firstAddress= results[0];

var latitude = firstAddress.geometry.location.lat();
var longitude = firstAddress.geometry.location.lng();
var marker = create(latitude , longitude);
invokeSuccessCallback( successCallback, marker);
}
else 
{
	alert('unknown address' + address);
}
})
};
function createByCurrentLocation (successCallback){
if(navigator.geolocation){
navigator.geolocation.getCurrentLocation(function (position){
var marker = create(position.coords.latitude,position.coords.logitude);
invokeSuccessCallback( successCallback ,marker);

});
}
else
{
	alert("unable to locate the location");
}

};

return {
       createByCroods: createByCroods,
       createByAddress: createByAddress,
       createByCurrentLocation: createByCurrentLocation
	}
});

app.controller("mapCtrl" ,function(mapFactory ,$scope){

mapFactory.createByCroods(45.000 , -56.765, function(marker){

marker.options.labelContent ='india';
$scope.indiaMarker = marker;
});

$scope.address ='';

$scope.map ={
  center :{
	latitude : $scope.indiaMarker.latitude,
	longitude : $scope.indiaMarker.longitude
},
zoom : 8,
markers :[],
controls :{},
options :{
	scrollwheel: false
}
};

$scope.map.markers.push($scope.indiaMarker);

$scope.addCurrentLocation = function(){
mapFactory.createByCurrentLocation(function(marker){
marker.options.labelContent='you are here';
$scope.map.markers.push(marker);
refresh(marker);
});
};

$scope.addAddress = function(){
	var address =$scope.address;
	if( address!= ''){
mapFactory.createByAddress(address ,function(marker){
$scope.map.markers.push(marker);
refresh(marker);

});
}
};

$scope.refresh =function(marker){
$scope.map.controls.refresh({latitude: marker.latitude , longitude: marker.longitude});

}
});