// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
})

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider

  // setup an abstract state for the tabs directive
  //   .state('tab', {
  //   url: '/tab',
  //   abstract: true,
  //   templateUrl: 'templates/tabs.html'
  // })

  // // Each tab has its own nav history stack:



  .state('login', {
    url: '/login',
   
      
        templateUrl: 'templates/login.html',
        controller: 'DashCtrl'
      
    
  })


  .state('home', {
   url: '/home',
   
     
       templateUrl: 'templates/home.html',
        controller: 'homectrl',
     
   onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
 })

  // .state('home', {
  //   url: '/home',
    
    
  //   templateUrl: 'templates/home.html',
  //       controller: 'productCtrl'
  //  //    onEnter: function($state, Auth){
  //  //     if(!Auth.isLoggedIn()){
  //  //        $state.go('login');
  //  //     }
  //  // }
 
  // })

  
.state('scan', {
    url: '/scan',
    
   templateUrl: 'templates/scan.html',
    onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
 
  })



.state('scan-code', {
    url: '/scan-code',
   templateUrl: 'templates/scan-code.html',
       onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })

.state('lookup_scan', {
    url: '/lookup_scan',
    
    
      
        templateUrl: 'templates/lookup_scan.html',
       onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })


.state('move', {
    url: '/move',
    
    
      
        templateUrl: 'templates/move.html',
       
      
    onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })

.state('stock_check', {
    url: '/stock_check',
   
   
      
        templateUrl: 'templates/stock_check.html',
       
      
    onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })

.state('query', {
    url: '/query',
    templateUrl: 'templates/query.html'
   
  })

.state('quantity-adjust', {
    url: '/quantity-adjust',
   
      
        templateUrl: 'templates/quantity-adjust.html',
       onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })

.state('query_2', {
    url: '/query_2/:sale_id',
  templateUrl: 'templates/query_2.html',
  controller: 'singleproductCtrl'
   //     onEnter: function($state, Auth){
   //     if(!Auth.isLoggedIn()){
   //        $state.go('login');
   //     }
   // }
  })


.state('Transfer-stock', {
    url: '/Transfer-stock',
    
    
      
        templateUrl: 'templates/Transfer-stock.html',
       
      
    onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })

.state('lookup', {
    url: '/lookup',
    
  
      
        templateUrl: 'templates/lookup.html',
       
      
    onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })


.state('detail', {
    url: '/detail',
     templateUrl: 'templates/detail.html',
     controller: 'productCtrl'
      
    ,onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })

.state('despatch', {
    url: '/despatch',
    
    
      
        templateUrl: 'templates/despatch.html',
       
      
  onEnter: function($state, Auth){
       if(!Auth.isLoggedIn()){
          $state.go('login');
       }
   }
  })

$urlRouterProvider.otherwise('/login');

});



// .state('scan', {
//       url: '/scan',
//     templateUrl: 'templates/scan.html'
      
//     })



  //demo
  


  // .state('home', {
  //     url: '/home',
  //   templateUrl: 'templates/home.html',
  //    controller: 'homectrl',
  //    onEnter: function($state, Auth){
  //      if(!Auth.isLoggedIn()){
  //         $state.go('login');
  //      }
  //  }
  //   })
    
    //   .state('scan', {
    //   url: '/scan',
    // templateUrl: 'templates/scan.html'
      
    // })
  // .state('scan-code', {
  //     url: '/scan-code',
  //   templateUrl: 'templates/scan-code.html'
      
  //   })
  // .state('lookup_scan', {
  //     url: '/lookup_scan',
  //   templateUrl: 'templates/lookup_scan.html'
      
  //   })
  // .state('move', {
  //     url: '/move',
  //   templateUrl: 'templates/move.html'
      
  //   })
   // .state('stock_check', {
   //    url: '/stock_check',
   //  templateUrl: 'templates/stock_check.html'
      
   //  })

  // .state('query', {
  //     url: '/query',
  //   templateUrl: 'templates/query.html'
      
  //   })
  // .state('quantity-adjust', {
  //     url: '/quantity-adjust',
  //   templateUrl: 'templates/quantity-adjust.html'
      
  //   })
  
  
  
  
  
  
  // .state('query2', {
  //     url: '/query2',
  //   templateUrl: 'templates/query_2.html'
      
  //   })
  // .state('Transfer-stock', {
  //     url: '/Transfer-stock',
  //   templateUrl: 'templates/Transfer-stock.html'
      
  //   })
  // .state('lookup', {
  //     url: '/lookup',
  //   templateUrl: 'templates/lookup.html'
      
  //   })
  // .state('detail', {
  //     url: '/detail',
  //   templateUrl: 'templates/detail.html'
      
  //   })
  // .state('despatch', {
  //     url: '/despatch',
  //   templateUrl: 'templates/despatch.html'
      
  //   })
  

  