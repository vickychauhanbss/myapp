var app =angular.module('starter.controllers', [])
app.constant('api','http://amboff.indiit.com/inventorymanagement/webservice/')
app.controller('DashCtrl' ,function($scope, $state ,$location,$ionicPopup,$ionicHistory,LoaderService,LoginService,Auth) {
 
$scope.data={};
$scope.login = function() {
if($scope.data.username === undefined ){
           var alertPopup = $ionicPopup.alert({
               title: 'Error',
               template: 'Please enter your username!'
           });
           return;
       }
       if($scope.data.password === undefined ){
           var alertPopup = $ionicPopup.alert({
               title: 'Error',
               template: 'Please enter your password!'
           });
           return;
       }
       LoaderService.show();
     
       LoginService.loginUser($scope.data.username, $scope.data.password).success(function(response) {
           
           LoaderService.hide();
           console.log(response.data);
           if (response.status == 1) {
//                console.log(response.data);
           $ionicHistory.clearCache()
               Auth.setUser(response.data);
                   window.localStorage.setItem('user_session',JSON.stringify(response.data));
                   user_detail = response.data;
                   console.log( user_detail);
                   var alertPopup = $ionicPopup.alert({
                       title: 'Success',
                       template: 'Successfully loged in!'
                   }).then(function(){
                       $state.go('home');
                   });
                   
                   return response.data;
//                    nukeService.data  = response.data.data;
//                    return nukeService;
//                    console.log(response_data);
//                    return response_data;
//                    console.log(response_data);
//                    return response.data.data;
                   // success
               }else if(response.status == 0) {
                   var alertPopup = $ionicPopup.alert({
               title: 'Login failed!',
               template: "Please Check Your Credentials"
           });
               } else {
                   var alertPopup = $ionicPopup.alert({
               title: 'Login failed!',
               template: 'Something went wrong'
           });
       }
//            $state.go('tab.dash');
       }) .error(function(data){
               LoaderService.hide();
                var alertPopup = $ionicPopup.alert({
               title: 'Error',
               template: 'Please check your network connection!'
               }).then(function(){
//                       $ionicHistory.getBackView();
                  });;
            });
//                .error(function(data) {
//            var alertPopup = $ionicPopup.alert({
//                title: 'Login failed!',
//                template: 'Please check your credentials!'
//            });
//        });
   }


})


app.controller('homectrl', function($scope) {
  // $scope.appData = JSON.parse( window.localStorage.getItem('mydata'));
  // console.log($scope.appData);
  // $state.go('home');
  })


app.controller('productCtrl', function($scope, $state ,$location,$ionicPopup,$ionicHistory,productService,LoaderService,Auth,singleProductService) {
$scope.data ={};
console.log(Auth.getUser());
console.log(Auth.getUser().id);
 LoaderService.show();
function get_data(){
productService.panding(Auth.getUser().id).success(function(response) {
          LoaderService.hide();
           // console.log(response.data.id);
            if (response.status == 1) {

            // $ionicHistory.clearCache()
        $scope.data = response.data;
        console.log("$scope.data")
                   // $state.go('detail');
              // return response.data;

//                    nukeService.data  = response.data.data;
//                    return nukeService;
//                    console.log(response_data);
//                    return response_data;
//                    console.log(response_data);
//                    return response.data.data;
                   // success
               }else if(response.status == 0) {
                   var alertPopup = $ionicPopup.alert({
               title: 'Login failed!',
               template: "Please Check Your Credentials"
           });
                   

}
})
}
get_data();
})



app.controller('singleproductCtrl', function($scope, $state ,$location,$ionicPopup,LoaderService,Auth,singleProductService,$stateParams) {
$scope.data ={};
var sale_id= $stateParams.sale_id;

// console.log(Auth.getUser().id);
function query_2(){
singleProductService.singleProduct(sale_id).success(function(response) {
          LoaderService.hide();
           // console.log(response.data.id);
            if (response.status == 1) {

            // $ionicHistory.clearCache()
        $scope.data = response.data;
        console.log($scope.data);

}
})
}
query_2();
})
