var app =angular.module('starter.services', [])
app.constant('api','http://amboff.indiit.com/inventorymanagement/webservice/')
app.service('LoaderService', ['$ionicLoading',function($ionicLoading){
       return {
           show : function(){
               $ionicLoading.show({
                       template:'\
                   <ion-spinner icon="lines"></ion-spinner>\
                   <div>Please wait!!!</div>\
                   ',
               content: 'Loading',
               animation: 'fade-in',
               showBackdrop: false,
               maxWidth: 200,
               showDelay: 0
             }); 
           },
           hide:function(){
               $ionicLoading.hide();
           }
       }
}])
.service('LoginService', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {
   
   return {
       loginUser: function(username, password) {
        console.log(username);
        console.log(password);
           
//            user['password'] = password;
           return $http({
               method: 'get',
               url: api+'login?username='+username+"&password="+password,
               //data: $httpParamSerializer(user),
                headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
           
           }).success(function(response) {
               return response;
               console.log(response);
               if (response.data.status == 1) {
                   return response.data;
//                    nukeService.data  = response.data.data;
//                    return nukeService;
//                    console.log(response_data);
//                    return response_data;
//                    console.log(response_data);
//                    return response.data.data;
                   // success
               } else {
                   return false;
               }
           }).error(function(response){
            return response;
           });
       }
   }
}])

.service('productService', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {


return {
       panding: function(id) {
        console.log(id);
 return $http({
  method: 'get',
  url: api+'get_pending_products?user_id='+id,
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);
               if (response.data.status == 1) {
                   return response.data;
//                    nukeService.data  = response.data.data;
//                    return nukeService;
//                    console.log(response_data);
//                    return response_data;
//                    console.log(response_data);
//                    return response.data.data;
                   // success
               } else {
                   return false;
               }
           });
       }
   }


}])


.service('singleProductService', ['$http',"$timeout","$location","api","$httpParamSerializer", function($http,$timeout,$location, api,$httpParamSerializer) {


return {
       singleProduct: function(id) {
        console.log(id);
 return $http({
  method: 'get',
  url: api+'get_pending_products?sale_id='+id,
            
headers: {
   'Authorization': 'Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ=='}
}).success(function(response) {
               return response;
               console.log(response);
               if (response.data.status == 1) {
                   return response.data;
//                    nukeService.data  = response.data.data;
//                    return nukeService;
//                    console.log(response_data);
//                    return response_data;
//                    console.log(response_data);
//                    return response.data.data;
                   // success
               } else {
                   return false;
               }
           });
       }
   }


}])


.factory('Auth', ['$state', function($state) {
//    console.log("hello");die();
  if (window.localStorage['user_session']) {
     var _user = JSON.parse(window.localStorage['user_session']);
  }
//   console.log(user_session);
  var setUser = function (user_session1) {
     _user = user_session1;
     window.localStorage['user_session'] = JSON.stringify(_user);
     user_detail = JSON.stringify(_user);
  }
//die();
  return {
     setUser: setUser,
     isLoggedIn: function () {
        return _user ? true : false;
     },
     getUser: function () {
        return _user;
     },
     logout: function () {
        window.localStorage.removeItem("user_session");
        window.localStorage.removeItem("list_dependents");
        user_detail = {};
        _user = null;
        $state.go('login');
     }
  }
}])