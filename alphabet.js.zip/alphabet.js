<script>
function abc(str)
{
return str.split("").sort().join("");
}
console.log(abc("abcde"));
<script>
