var app=angular.module("myapp",['ngRoute']);
app.config(function($routeProvider){

$routeProvider.
when('/login' ,{
controller:"loginCtrl",
templateUrl:"/javascripts/views/login.html"
}).
when('/signup' ,{
controller:"loginCtrl",
templateUrl:"/javascripts/views/signup.html"
}).
when('/view' ,{
controller:"loginCtrl",
templateUrl:"/javascripts/views/view.html"
}).
otherwise({
      redirectTo:'/login'
         });
});