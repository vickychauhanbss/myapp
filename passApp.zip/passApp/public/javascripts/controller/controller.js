app.controller("loginCtrl" ,function($scope){
$scope.msg ="this is login page";
});