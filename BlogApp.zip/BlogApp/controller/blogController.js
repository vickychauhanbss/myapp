var blogModel = require('../models/blogModel');
var commentModel = require('../models/commentModel');
var auth=require('./auth.js');
module.exports.addBlog=function(req,res){
var blog=new blogModel();
blog.title=req.body.title;
blog.content=req.body.content;
blog.tags=req.body.tags;
console.log(req.body.tags);
blog.images=req.file.filename;
blog.email=req.body.email;
blog.createdby= req.body.createdby;
blog.name= req.body.name;
var uid=req.params.id;
//console.log(uid);

blog.save(function(err,blog){
	if(err){
		console.log('err',err)
	}else{
		console.log(blog);
		res.send(blog);
		//res.redirect("/list")
	}

})
}
module.exports.addComment=function(req,res){
var comment=new commentModel();
comment.name= req.body.name;
comment.email= req.body.email;
comment.comments= req.body.comments;
//var uid=req.params.id;
console.log(req.body);
comment.save(function(err,comment){
  if(err){
    console.log('err',err)
  }else{
    console.log(comment);
    res.send(comment);
    //res.redirect("/list")
  }

})
}
module.exports.viewComments = function(req,res){
   commentModel.find({},function(err,comment){
    if(err){
    res.send(err);
  }else{
      res.send(comment)
      //res.redirect("/list")
    }
   });
}

module.exports.viewsigleBlog = function(req,res){
	 blogModel.find({email:req.params.email},function(err,blog){
		if(err){
		res.send(err);
	}else{
			res.send(blog)
			//res.redirect("/list")
		}
	 });
}


module.exports.viewALLBlog = function(req,res){
   blogModel.find({},function(err,blog){
    if(err){
    res.send(err);
  }else{
      res.send(blog)
      console.log(blog);
      //res.redirect("/list")
    }
   });
}
module.exports.removeData=function (req, res){
	console.log(req.params.id);
  blogModel.findById(req.params.id, function ( err, blog ){
    blog.remove(function (err, blog ){
      //res.redirect( '/list' );
      res.send(blog)
      console.log("delete");
    });
  });
}

// module.exports.editBlog=function(req,res,next){
// 	blogModel.findById(req.params.id,function(err,blog){
// 		if(err){
// 			res.send(err);
// 		}
// 		else{
// 			//req.session.user=person;
// 			res.send(blog);
// 			//res.render('singel-blogview');
// 		}
// 	})
// }


module.exports.editBlog=function (req, res ){
	blogModel.findById(req.params.id, function ( err, blog ){
  	if(err){
    		res.json(err);
    	}else{
        res.send(blog);
//req.session.user=person;
     // res.redirect( '/');
  }
    });
  }
module.exports.saveEditBlog=function (req, res ){
  console.log(req.body);
  blogModel.findById(req.params.id, function ( err, blog ){
    blog.title =req.body.title;
    blog.content  = req.body.content;
    blog.tags  = req.body.tags;
    //blog.images  = req.file.filename;
    blog.save( function ( err, blog ){
      if(err){
        res.json(err);
      }else{
    // req.session.user=person;
      //res.redirect( '/list');
      res.send(blog)
  }
    });
  });
}
