var ContactModel = require('../models/contactModel');
var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport('smtps://sunpreetckd@gmail.com:shaanshergill@smtp.gmail.com');

 
/**
 * Send an email when the contact from is submitted
 */
module.exports.saveContactForm = function(req, res) {
 var contact = new ContactModel();
	var data = req.body;
 //contact.name = req.body.name;
 //contact.email = req.body.email;
  transporter.sendMail({
        from: data.email,
        to: 'mangalhcl449@gmail.com,sunpreetckd@gmail.com',        
		name:data.name,		
        text: data.message

    });
 
    res.json(data);
};

/*var ContactModel = require('../models/contactModel.js');

module.exports.saveContactForm = function(req, res) {
var user= new ContactModel();
//console.log(user);
user.name=req.body.name;
user.email=req.body.email;
user.message=req.body.message;
ContactModel.findOne({email:req.body.email},function(err,person){
	if(err){
		console.log('err',err);
	}else{
		if(!person){
			user.save(function(err,data){
				if(err){
					res.send(err);
				}else{
					res.send(data);
				}
			});
		}else{
			res.send({error:'Email is already register'});
		}
	}
});
}*/
