var Usermodel = require('../models/userModel');

module.exports.signup=function(req,res){
var user=new Usermodel();
user.local.name=req.body.name;
user.local.username=req.body.username;
user.local.email=req.body.email;
user.local.password=req.body.password;
user.local.pic= req.file.filename;
Usermodel.findOne({'local.email':req.body.email},function(err,person){
	if(err){
		console.log('err',err)
	}else{
		if(!person){
			user.save(function(err,person){
				if(err){
					res.send(err);
				}else{
					res.send(person);
					console.log(person);
					//res.redirect("/login")
				}
			});
		}else{
			res.send({error:"Email is already taken"});
		}
	}

})
}

// module.exports.login=function(req,res){
// var email=req.body.email;
// var password=req.body.password;
// console.log(email);
// 			Usermodel.findOne({email:email},function(err,person){
// 				if(err){
// 					console.log('err',err);
// 					}
// 					else{
// 						if(person){
// 							if(person.password==password && person.email == email){
// 						        console.log(person)
// 								res.send(person);
// 								//res.render('home',{title:"home", data:person.email});

// 							}
// 							else{
// 								//res.send({error:'incorrect password'});
// 								res.redirect('/login')
// 							}
// 						}else{
// 							//res.send({error:'User name or password is worng'})
// 								res.redirect('/login')

// 						}
// 					}
// 				})
//      }
