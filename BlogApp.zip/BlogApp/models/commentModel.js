
var mongoose=require("mongoose");
var Schema= mongoose.Schema;

var CommentSchema = new Schema({
   name: String,
   email:String,
   comments:String,
});
var comment = mongoose.model('comment', CommentSchema);
//console.log(Blog)
module.exports = comment;