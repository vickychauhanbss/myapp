var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var contactSchema = new Schema({
  name: String,
  email: { type: String, required: true, unique: true },
  message:String
});
var contactUser = mongoose.model('contactUser', contactSchema);
module.exports = contactUser;
