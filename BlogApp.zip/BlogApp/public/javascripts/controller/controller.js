app.controller("HomeCtrl", function($scope){
	$scope.message="hiii";
});

app.controller("login", function($scope,$location,$http,createUser,Auth,$localStorage){
$scope.userLogin=function(){
  Auth.setUser($scope.username,$scope.password); 
  //prompt("entre user")
}
$scope.userlogged=$localStorage.LoginUser;
console.log($scope.userlogged);
});

app.controller("SignUp", function($scope,$location,$http,createUser){

$scope.uploadFile = function(){
  createUser.signUpuser($scope.registration.user.name,$scope.registration.user.username,$scope.registration.user.email,$scope.registration.user.password,$scope.registration.user.myFile)
  }

});
app.controller("addBlogView", function($localStorage,$scope,$http,$location,Auth){
   $scope.userlogged=$localStorage.LoginUser;
	$scope.blogFile = function(){
 var uploadUrl = "api/addBlog";
        var fd = new FormData();
        console.log(fd);
         var file = $scope.myFile;
        fd.append('title',$scope.title);
        fd.append('content',$scope.content);
        fd.append('tags',$scope.tags);
        fd.append('file', file);
        fd.append('email', $scope.userlogged.email);
        fd.append('name', $scope.userlogged.name);
        //JSON.stringify({name:$scope.registration.user.name,email:$scope.registration.user.email,password:$scope.registration.user.password, file:file})
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(){
           console.log("success!!");
          $location.path("/list")
        })
        .error(function(){
          console.log("error!!");
        });
    };





});

app.controller("blogView", function($scope,$http,$localStorage,$location,$routeParams,Auth){
  $scope.updateValue= $localStorage.dd;
  $scope.userlogged=$localStorage.LoginUser;
  //console.log( $scope.userlogged);
angular.element(document).ready(function(){
		$http({
		method:"get",
		url:'api/viewALLBlog',
	}).then(function successCallback(response) {
			if(response.data.error){
				$scope.error = response.data.error;
			}else{
   $scope.Blog=response.data;
console.log($scope.Blog);
   $scope.currentPage = 1;
  $scope.totalItems = $scope.Blog.length;
  //console.log($scope.totalItems);
  $scope.entryLimit = 9; 
  $scope.noOfpages = Math.ceil($scope.totalItems / $scope.entryLimit);
        //console.log($scope.Blog)
				if($routeParams.id!=undefined){
          $scope.Blog.forEach(function(value,index) {

            console.log($scope.Blog);
            if(value._id == $routeParams.id){
              $scope.oneBlog = value;
              //console.log($scope.oneBlog);
            }
          
          })
        }
			}
			//console.log(response);
		}, function errorCallback(response) {
			console.log('error',response);
		});
	});
angular.element(document).ready(function(){
  var email=$scope.userlogged.email;
    $http({
    method:"get",
    url:'api/viewSingleALLBlog/' +email,
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
   $scope.singleBlog=response.data;
    //console.log($scope.Blog)
    if($routeParams.id!=undefined){
          $scope.singleBlog.forEach(function(value,index) {

            console.log($scope.singleBlog);
            if(value._id == $routeParams.id){

              $scope.oneBlog = value;
  
              //console.log($scope.oneBlog);
            }
          
          })
        }
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });
  });

////addcomment
$scope.likes=0;
$scope.comment=0;
$scope.countLikes=function(){
$scope.likes++;
}
$scope.addComment=function(){
  // $http.post({
  //   url:'api/comment',
  //   method:'post',
  //   data:{name:$scope.oneBlog.name, comments:$scope.oneBlog.comments}
  // }).then(function successCallback(response){
  //   $scope.comment=response.data;
  //   console.log($scope.comment);
  // },function errorCallback(response){
  //   console.log('error',response);
  // });
$http({
    method:"post",
    url:'api/comment',
   data:{name:$scope.myform.name, email:$scope.myform.email, comments:$scope.myform.comments},
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.commentData=response.data;
          $scope.comment++;
          $scope.myform={};
        console.log($scope.commentData)
       //$location.path("/");
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });

};
$scope.getaddComment=function(){
$http({
    method:"get",
    url:'api/comment',
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.getcommentData=response.data;

   
        console.log($scope.getcommentData)
       //$location.path("/");
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });
};
$scope.removePost = function(id) {
        $http({ 
                url: 'api/delete/'+ id ,
                method: 'delete'
        }).then(function(res) {
            $scope.singleBlog.forEach(function(value,index){
              if(value._id == id){
                $scope.singleBlog.splice(index,1);
              }
            })
        }, function(error) {
            console.log(error);
        });
    };
$scope.singlebLogView = function(id) {
    $location.path("/"+ id);
} 

$scope.editBlog = function(id) {
$http({
    method:"get",
    url:'api/edit/'+id,
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog=response.data;

        $localStorage.dd=$scope.Blog;
        
        //console.log( $scope.updateValue)
        $location.path('/editBlog');
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });


}
$scope.svaUpdateData = function(id) {
$http({
    method:"put",
    url:'api/edit/'+id,
    data:{title:$scope.updateValue.title,content:$scope.updateValue.content,tags:$scope.updateValue.tags}
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog=response.data;
        //console.log( $scope.updateValue)
        $location.path('/list');
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });
}
 
});

app.controller("contactUs", function($scope,$location,$http,contactus){
$scope.contactSave=function(){
 if ($scope.myForm.$valid) {
 contactus.contact($scope.name,$scope.email,$scope.message);
   $scope.name="";
  $scope.email="";
  $scope.message="";
} else {
$scope.response = "Please fill in the required fields";
}

}

});
app.controller('mainCtrl', ['$scope','Auth','contactus', '$location','$localStorage','$window', '$http',function ($scope,Auth, contactus,$location,$localStorage,$window,$http) {
   $scope.checkuser=false;
  $scope.checkLoggedUSer=function(){
    $scope.$watch(Auth.isLoggedIn, function (value) {
    if(value) {
       $scope.checkuser=true;
      console.log("Connect");
    
    }else{
  console.log("Disconnect");
      $location.path('/login');
    }
   
  }, true);
  }

 //  $scope.userCheck=function(){
 // $scope.userlogged=$localStorage.LoginUser;
 // Auth.isLoggedIn()
 //    // if(Auth.isLoggedIn){
 //      $scope.checkuser=true;
 //    //   console.log(Auth.isLoggedIn)
 //    // }
 //    // else{
 //    //   $scope.checkuser=false;
 //    // }
 //  }
$scope.logOut=function(){
$http({
    method:"get",
    url:'/api/logout',
}).then(function successCallback(response){
  $scope.checkuser=false;
  $location.path('/login');
}, function errorCallback(res){
  console.log("error");
});

  }
$scope.contactus=function(){
   $location.path('/contactUs');
}
}]);

