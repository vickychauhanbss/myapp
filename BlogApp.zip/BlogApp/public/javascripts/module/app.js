var app =angular.module('myApp', ['ngRoute' ,'ngMessages','ngStorage','ui.bootstrap'])
    app.config(['$routeProvider','$locationProvider', function($routeProvider,$locationProvider) {
        $routeProvider.
                   when('/signUp', {
                    templateUrl: 'javascripts/view/signup.html', 
                     controller: 'SignUp'
                   }).
                   when('/login', {
                    templateUrl: 'javascripts/view/login.html', 
                     controller: 'login'
                   }).
                when('/home', {
                 	templateUrl: 'javascripts/view/home.html', 
                     controller: 'blogView'
                  }).
                when('/blog', {
                 	templateUrl: 'javascripts/view/blog.html', 
                     controller: 'blogView'
                   }).
                 when('/add', {
                 	templateUrl: 'javascripts/view/add.html', 
                     controller: 'addBlogView',
                     resolve: {
                        logedin:checkLoggedin
                         }
                   }).
                 when('/profile', {
                    templateUrl: 'javascripts/view/profile.html', 
                     controller: 'login',
                     resolve: {
                     logedin:checkLoggedin
                     }
                   }).
                 when('/list', {
                 	templateUrl: 'javascripts/view/list.html', 
                     controller: 'blogView',
                    resolve: {
                   logedin:checkLoggedin
                        }
                //    }
                   }) .
                   when('/contactUs', {
                 	templateUrl: 'javascripts/view/contactUs.html', 
                     controller: 'contactUs'
                   })
                   .when('/editBlog' ,{
                    templateUrl: 'javascripts/view/updateBlog.html', 
                     controller: 'blogView',
                     resolve: {
                        logedin:checkLoggedin
                         }
                   }).
                    when('/:id', {
                     templateUrl: function() {
                        return 'javascripts/view/singel-blogview.html';
                    },
                     controller: 'blogView'
                   }).otherwise({
                   redirectTo: '/home'
                   });
                $locationProvider.html5Mode({
                 enabled: true,
                requireBase: false
              });

}]);
var checkLoggedin = function($q, $timeout, $http, $location, $rootScope){
      // Initialize a new promise
      var deferred = $q.defer();
      $http.get('/api/loggedin').success(function(user){
        // Authenticated
        if(user !== '0'){
          //$timeout(deferred.resolve, 0);
        console.log("you are log in " + user);
          deferred.resolve();
             }
        // Not Authenticated
        else {
          $rootScope.message = 'You need to log in.';
          console.log("you are not log in " + user);
          deferred.reject();
         // $timeout(function(){deferred.reject();}, 0);
          $location.url('/login');
        }
      });
      return deferred.promise;
    };
// app.run(['$rootScope', '$location', 'Auth', function ($rootScope, $location, Auth) {
//         if(Auth.isLoggedIn()){
//             $location.path('/home');
//         }else{
//             $location.path('/login');
// }
// }]);

app.directive('compareTo', [function() {
    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function(scope, element, attributes, ngModel) {
             
            ngModel.$validators.compareTo = function(modelValue) {
                return modelValue == scope.otherModelValue;
            };
 
            scope.$watch("otherModelValue", function() {
                ngModel.$validate();
            });
        }
    };
}]); 
app.directive('fileModel', ['$parse', function ($parse) {
return {
    restrict: 'A',
    link: function(scope, element, attrs) {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                modelSetter(scope, element[0].files[0]);
            });
        });
    }
};
}]);

///f

    app.filter('startFrom', function () {
    return function (input, start) {
        if (input) {
            start = +start;
            return input.slice(start);
        }
        return [];
    };
});