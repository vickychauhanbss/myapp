app.service('createUser',function($location,$http,$localStorage){
this.signUpuser = function(name,username,email,password,file){
       // var file = $scope.registration.user.myFile;
      var uploadUrl = "api/signup";
        var fd = new FormData();
        fd.append('name',name);
        fd.append('username',username);
        fd.append('email',email);
        fd.append('password',password);
        fd.append('file', file);
        //JSON.stringify({name:$scope.registration.user.name,email:$scope.registration.user.email,password:$scope.registration.user.password, file:file})
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(res){
         $localStorage.userData=res;

      
           //console.log($localStorage.userData)
          $location.path("/login")
        })
        .error(function(){
          console.log("error!!");
        });
    };
})

app.factory('Auth', function($http,$location, $localStorage){
var userLog;
var log;
// var userLogindata=$localStorage.LoginUser;
//console.log(userLog);
//var isLogin;
return{
    setUser : function(username,password){
       $http({
	method:"POST",
	url:'api/login',
	data:{username:username,password:password},
}).then(function successCallback(response) {
	   var  userLog=response.data;
       $localStorage.LoginUser=  userLog ;
  //log =$localStorage.LoginUser;
    //console.log($localStorage.LoginUser.local.username )
        $location.path('/home');
        if($localStorage.LoginUser.local.username == username && $localStorage.LoginUser.local.password == password){
         log=$localStorage.LoginUser;
       	alert("You are valid user");
       	$location.path('/home');
       }else{
       	   	alert("You are not valid user plz sign in");
       	   		$location.path('/signUp');
        }
     
	}, function errorCallback(response) {
		  console.log('error');
		    alert("username or password is not valid");
		   $location.path('/signUp');
	});

    },
    isLoggedIn : function(){
    return (log)? log=true : log=false;
    console.log(log)
    },
     isLoggedOut : function(){
    return log =false;
    }
  }
  
})


app.service('contactus', function($http,$location, $localStorage){
this.contact=function(name,email,message){
  $http({
  method:"POST",
  url:'api/contactsave',
  data:{name:name , email:email,message:message},
}).then(function successCallback(response) {
      $location.path('/contactUs');
    console.log(response);
  }, function errorCallback(response) {
    console.log('error',response);
  });
};
});