var express = require('express');
var router = express.Router();
var mime = require('mime-types')
var multer  = require('multer');
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
//var upload = multer({ dest: 'uploads/' });
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+mime.extension(file.mimetype));
    }
});
var upload = multer({ storage: storage });
//var upload = multer({ dest: 'uploads/' });
var Blogstorage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/blogUpload/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+mime.extension(file.mimetype));
    }
});
//passport
var userController=require('../controller/userController');
var blogController=require('../controller/blogController');
var contactController=require('../controller/contactController');
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var Usermodel = require('../models/userModel');

// function ensureAuthenticated(req, res, next){
//     if(req.isAuthenticated()){
//         return next();
//     } else {
//         req.flash('error_msg','You are not logged in');
//         res.redirect('/login');
//     }
// }
//******------------------------------------
// passport.use(new LocalStrategy(function(username, password, done) {
//     Usermodel.findOne({name: username }, function(err, user) {
//       if (err) { return done(err); }
//       if (!user) {
//         return done(null, false, { message: 'Incorrect username.' });
//       }
//       if (user.password != password) {
//         return done(null, false, { message: 'Incorrect password.' });
//       }
//       return done(null, user);
//     });
//   }));

//passport serialize user for their session
// passport.serializeUser(function(user, done) {
//   done(null, user.id);
// });
// //passport deserialize user 
// passport.deserializeUser(function(id, done) {
//   User.findById(id, function(err, user) {
//     done(err, user);
//   });

///***********************************
var upload = multer({ storage: storage });
var blogUpload = multer({ storage: Blogstorage });
/* GET home page. */

router.get('/loggedin', function(req, res) {
  res.send(req.isAuthenticated() ? req.user : '0');
});


//*******************passsport Authentication****************************//
passport.use(new LocalStrategy(function(username, password, done) {
    Usermodel.findOne({'local.username': username }, function(err, user) {
      if (err) { return done(err); }
      if (!user) {
        return done(null, false, { message: 'Incorrect username.' });
      }
      if (user.local.password != password) {
        return done(null, false, { message: 'Incorrect password.' });
      }
      return done(null, user);
     // console.log(user)
    });
  }));

//passport serialize user for their session
passport.serializeUser(function(user, done) {
  done(null, user.id);
});
//passport deserialize user 
passport.deserializeUser(function(id, done) {
  Usermodel.findById(id, function(err, user) {
    done(err, user);
  });
});
//********************************************
router.post('/login', passport.authenticate('local'), function(req, res) {
  res.send(req.user);
});
//router.post('/login',userController.login);
// router.post('/login', passport.authenticate('local', {successRedirect:'/', failureRedirect:'/login'}),function(req, res) {
//     res.redirect('/');
//   });
router.get('/logout', function(req, res){
    req.logout();
    res.send(req.user)
    console.log("user is logout")
    // res.redirect('/login');
});

router.post('/signup',upload.single('file'),userController.signup);
router.post('/addBlog',blogUpload.single('file'),blogController.addBlog);
router.get('/viewSingleALLBlog/:email',blogController.viewsigleBlog);
router.get('/viewALLBlog' ,blogController.viewALLBlog);
router.post('/comment',blogController.addComment);
router.get('/comment',blogController.viewComments);
router.delete('/delete/:id', blogController.removeData);																								
//router.get('/singBlog/:id', blogController.singleBlog);    
router.get('/edit/:id', blogController.editBlog);
router.put('/edit/:id', blogController.saveEditBlog);  
router.post('/contactsave', contactController.saveContactForm);  

module.exports = router;
