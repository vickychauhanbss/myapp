var mime = require('mime-types')
var multer  = require('multer');
//**********************************
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+mime.extension(file.mimetype));
    }
});
//***************


//var upload = multer({ dest: 'uploads/' });
var Blogstorage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/blogUpload/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+mime.extension(file.mimetype));
    }
});