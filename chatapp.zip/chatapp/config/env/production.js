module.exports = {
    db:"mongodb://localhost/meandemo-dev",
    app: {
        name: "Mean Demo (Shankar Kamble)"
    }

}