var mongoose  = require("mongoose");
var Schema = mongoose.Schema;
var checkSchema = new Schema({
    fullname:String,
	email :String,
	address:String,
	city:String,
	state :String,
	country:String,
	mobile:String
});



var User = mongoose.model('check' ,checkSchema);
module.exports = User;