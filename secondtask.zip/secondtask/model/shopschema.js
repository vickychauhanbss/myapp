var mongoose  = require("mongoose");
var Schema = mongoose.Schema;
var shopSchema = new Schema({
    product:String,
	price :String,
	file:String
});



var User = mongoose.model('shop' ,shopSchema);
module.exports = User;