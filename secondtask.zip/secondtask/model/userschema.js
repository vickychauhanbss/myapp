var mongoose  = require("mongoose");
var Schema = mongoose.Schema;
var userSchema = new Schema({

	local:
	{
	name:String,
	username :{type: String, required:true},
    email :{type: String},
    password: { type: String, required: true },
    gender: String,
    file :String,
    status:Boolean,
    confirmation:String
}
});



var User = mongoose.model('user' ,userSchema);
module.exports = User;