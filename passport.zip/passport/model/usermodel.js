var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
	local:
	{
	name: String,
    username: {type:String,required: true, unique:true},
    password: String
    },
   google:
	{
	    id    : String, // your App ID
        token  : String, // your App Secret
        email  : String,
        name   : String
    }
    
   
    
});

var User = mongoose.model('user', userSchema);

module.exports = User;