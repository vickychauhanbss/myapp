var express = require('express');
var router = express.Router();
var model = require('../model/usermodel');

var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;
//------------------------------------------middle function------- 

function isAuth(req,res,next){
	if(req.isAuthenticated()){
		return next();
	}
	else {
		res.redirect('/');
	}
}
//--------------------------------google strategy ----------------

passport.use(new GoogleStrategy({
    clientID: '432437125796-66nvji2i0p2vqslcg0e80qr35dpjr8bt.apps.googleusercontent.com',
    clientSecret: '-HEqbUgIp1V3ae2PK3X8hBYr',
    callbackURL: "http://localhost:3000/auth/google/callback"
  },
  function(token, refreshToken, profile, done) {

        
            model.findOne({ 'google.id' : profile.id }, function(err, user) {
                if (err)
                    return done(err);

                if (user) {

                    
                    return done(null, user);
                } else {
                    
                    var newUser          = new model();

                   
                    newUser.google.id    = profile.id;
                    newUser.google.token = token;
                    newUser.google.name  = profile.displayName;
                    newUser.google.email = profile.emails[0].value; // pull the first email

                   
                    newUser.save(function(err) {
                        if (err)
                        {
                            return done(null, err);
                        }
                        return done(null, newUser);
                    });
                }
            });
        //});

    }
));

//---------------------------------google routes ----------------

router.get('/auth/google',
  passport.authenticate('google', { scope: ['https://www.googleapis.com/auth/plus.login','https://www.googleapis.com/auth/plus.profile.emails.read'] }));

  router.get('/auth/google/callback', 
  passport.authenticate('google', { failureRedirect: '/' }),
  function(req, res) {
    res.redirect('/alluser');
  });

//---------------------------- Local Strategy--------------------------
passport.use(new LocalStrategy(
  function(username, password, done) {
    model.findOne({ 'local.username': username }, function (err, user) {
      if (err) { return done(err); }
      if (!user) {
        return done(null, false, { message: 'Incorrect username.' });
      }
      if (!user.local.password == password) {
        return done(null, false, { message: 'Incorrect password.' });
      }
      return done(null, user);
    });
  }
));

//------------------------------------------


router.post('/login',passport.authenticate('local', 
{ 

  successRedirect: '/alluser',
  failureRedirect: '/' 
}
));



//==================================

passport.serializeUser(function(user, done) {
  done(null, user);
});

passport.deserializeUser(function(user, done) {
  done(null, user);
});



//''''''''''''''''''''''''''

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});

router.get('/logout', function(req, res, next) {
  req.logOut();
  res.redirect('/');
});





router.get('/signup', function(req, res, next) {
  res.render('signup');
});
router.get('/alluser',isAuth ,function(req, res,next) {
 model.find({},function(err,user){
		if(err){
			res.send(err);
		}else{
			console.log(user);
			//req.session.us=user
			res.render('view',{data:user});
			//res.redirect('/home')
		}
});
});

router.post('/signup', function(req, res){
	var user = new model();
    //console.log(req.body);
	user.local.name = req.body.name;
	user.local.username = req.body.username;
	
	user.local.password = req.body.password;
  
  //user.qualification = req.body.qualification+"|"+req.body.qualification1+"|"
  //+req.body.qualification2+"|"+req.body.qualification3;                                      
	model.findOne({'local.username':req.body.username}, function(err , person){

		if(err){
    		console.log('err',err)
    	}
    	else 
    	{
    		if(!person)
    		{
			    user.save(function (err, data) {
					if(err) 
					{   console.log(err);
						//res.send(err);
					}else 
					{
						//res.send("Data store");
						res.redirect('/');
					}
				});
			}
			else{
				res.send({error:'username is already register'});
			}
		}
	});
});



module.exports = router;
