var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var userSchema = new Schema({

local:
{
    name:String,
	username:{type:String, required:true , unique:true},
	password:String
},
google:
{
  id:String,
  token:String,
  email:String,
  name:String
}


});

var user = mongoose.model("user"  , userSchema);

module.exports = user;