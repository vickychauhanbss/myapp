var express = require('express');
var router = express.Router();


var model = require('../models/usermodel');

var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;




function isAuth(req,res,next){
	if(req.isAuthenticated()){

		return next();
	}
	else
	{
		res.redirect('/');
	}
}


passport.use(new GoogleStrategy({
    clientID: '432437125796-66nvji2i0p2vqslcg0e80qr35dpjr8bt.apps.googleusercontent.com',
    clientSecret: '-HEqbUgIp1V3ae2PK3X8hBYr',
    callbackURL: "http://localhost:3000/auth/google/callback"
  },
function(token ,refreshToken, profile ,done){
model.findOne({'google.id' : profile.id} , function(err,user){
if(err)
{
	return done(err);
}
if(user)
{
    return done(null ,user);
}
else
{
	var newuser = new model();

     newuser.google.id = profile.id;
     newuser.google.token = token;
     newuser.google.name = profile.displayname;
     newuser.google.email = profile.emails[0].value;
     
      newuser.save(function(err){
      if(err)
      {
      	return done(null ,err);
      }
      return done(null ,newuser);

     
	});
}

});

}
));

router.get('/auth/google',
 passport.authenticate('google', { scope: ['https://www.googleapis.com/auth/plus.login','https://www.googleapis.com/auth/plus.profile.emails.read'] }));

router.get('/auth/google/callback',
passport.authenticate ('google', { faliureRedirect :'/'}),

function(req,res){

	res.redirect('/alluser');
});


passport.use(new LocalStrategy(
function(username , password ,done){

model.findOne({'local.username':username} , function(err, user){

if(err)
{
	return done(err);
}
if(!user)
{
	return done(null ,false ,{massege :"username incorrect"});
}
if(!user.local.password == password)
{
	return done(null ,false ,{massege :"password incorrect"});
}
return done(null ,user);


});
}
));


router.post('/login' , passport.authenticate('local',
{
  successRedirect:'/alluser',
  failureRedirect:'/'
}
 ));

passport.serializeUser(function(user ,done){
 done(null ,user);
});

passport.deserializeUser(function(user ,done){
 done(null ,user);
});




/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('login');
});

router.get('/logout' ,function(req , res, next){
req.logOut();
res.redirect('/');
});



router.get('/signup', function(req, res, next) {
  res.render('signup');
});



router.get('/alluser',isAuth ,function(req ,res ,next){
model.find({} ,function(err, user){
if(err)
{
	res.send(err);
}
else
{
    console.log(user);	
	res.render('view' ,{data:user});
}
});
});


router.post('/signup' ,function(req ,res ,next){
var user = new model();

user.local.name = req.body.name;
user.local.username =req.body.username;
user.local.password =req.body.password;

model.findOne({'local.username':req.body.username} ,function(err , person){

if(err)
{
	res.send(err);
}
else
{
	if(!person)
	{
		user.save(function(err ,data){
        if(err){
        	res.send(err);
        }
        else
        {
        	res.redirect('/');
        }

});
	}

else
{
	console.log("username is already exist");
}

}
});


});



module.exports = router;
