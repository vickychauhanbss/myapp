var express = require("express");
var router = express.Router();
var userModel = require('../module/usermodel');

router.post('/login' , function(req ,res){
var email = req.body.email;
var password = req.body.password;
userModel.findOne({email:email},function(err , person) {
if(err){
res.send(err);
}
else
{
if(person.email == email && person.password == password){
res.send({data:person});
}
else
{

  res.redirect('/login');
	res.send({errer:"password incorrect"});

}
	
}
});
});


router.post('/signup' ,function(req ,res){
var user = new userModel();
user.name =req.body.name;
user.email = req.body.email;
user.password = req.body.password;
userModel.findOne({email:req.body.email} ,function(err ,person){
if(err)
{
	res.send(err);
}
else
{
  
    if(!person)
    {
      user.save(function(err,data){
          if(err)
          {
            res.send(err);
          }
          else
          {
            res.send(data);
          }
          });
    }
    else
    {
           res.send({error:"Email Already Register"});
    }
  } 
  
});
});
module.exports = router;