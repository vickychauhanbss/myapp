
app.controller("loginCtrl" , function($scope ,$location ,$http){
$scope.msg = "this is home page";
$scope.login =function(){
$http({
     method:'post',
     url:'/api/login',
     data:{email:$scope.email,password:$scope.password},
 }).then(function successCallback(response){

 	if(response.data.error){
 		$scope.error=response.data.error;
 	}
 		else {
 			console.log(response.data);
              $location.path('/home');
 		}
 	},function errorCallback(response){
 		console.log('error',response);
 	});
}


$scope.signupon =function(){

	$location.path('/signup');
}


$scope.signup = function(){
   console.log('$scope.name',$scope.name ,'$scope.email',$scope.email);
    $http({
      method: 'post',
      url: '/api/signup',
      data: {name:$scope.name, email:$scope.email, password:$scope.password},
    }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
         //console.log('$scope.name',$scope.name ,'$scope.email',$scope.email);
        $location.path('/login');
      }
    }, function errorCallback(response) {
      console.log('error',response);
    });
  }


});