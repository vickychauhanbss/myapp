var app = angular.module("myapp" ,['ngRoute']);
app.config(function($routeProvider){
$routeProvider. when('/home' , {
controller:"loginCtrl",
templateUrl:"javascripts/views/home.html"
}).
when('/login' ,{
controller:"loginCtrl",
templateUrl:"javascripts/views/login.html"
}).
when('/signup' ,{
controller:"loginCtrl",
templateUrl:"javascripts/views/signup.html"
}).
otherwise({
redirectTo:'/home'
});
});
