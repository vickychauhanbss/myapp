var Usermodel = require('../model/userModel');


module.exports.signup = function(req,res){
  var user = new Usermodel();
  user.username = req.body.username;
  user.email = req.body.email;
  user.password = user.generateHash(req.body.password);
  user.myFile = req.file.filename;
  user.gender = req.body.gender;
  user.status =0;
  user.confirmation = makeid()

  Usermodel.findOne({email:req.body.email},function(err,person){
  	if(err){
  		console.log(err,'error');
  	}else{
  		if(!person){
  			user.save(function (err,data){
  				if(err){
  					res.send(err);
  				}else{
            var mailOptions = {
    from: '"Fred Foo 👥" <foo@blurdybloop.com>', // sender address
    to: 'bar@blurdybloop.com, baz@blurdybloop.com', // list of receivers
    subject: 'Hello ✔', // Subject line
    text: 'Hello world 🐴', // plaintext body
    html: '<b>Hello world 🐴</b>' // html body
};

// send mail with defined transport object
transporter.sendMail(mailOptions, function(error, info){
    if(error){
        return console.log(error);
    }
    res.send(data);
});

            
  					// res.send(data);
  				}
  			})
  		}else{
  			res.send({error:'email is already registered'});
  		}
  	}
  })
}

function makeid()
{
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < 5; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}