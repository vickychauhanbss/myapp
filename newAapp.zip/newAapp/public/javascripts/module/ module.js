
 var app = angular.module('myApp',['ngRoute','ngMessages','myApp.directives']);

app.config(['$routeProvider','$locationProvider',function($routeProvider,$locationProvider){
$routeProvider.when('/login',{
    
    templateUrl: 'javascripts/view/login.html',
    controller:'loginController'
})
.when('/signup',{
    
    templateUrl: 'javascripts/view/signup.html',
    controller:'loginController'
})
.when('/profile',{
    
    templateUrl: 'javascripts/view/profile.html',
    controller:'loginController'
    // resolve: {
    //          logedin:checkLoggedin
    // }
})
.otherwise({
    redirectTo:'/login'

});
$locationProvider.html5Mode({
      enabled: true,
     requireBase: false
      });
}]);


var app = angular.module('myApp.directives', ['ngMessages'])
 app.directive('compareTo', [function() {
    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function(scope, element, attributes, ngModel) {
             
            ngModel.$validators.compareTo = function(modelValue) {
                return modelValue == scope.otherModelValue;
            };
 
            scope.$watch("otherModelValue", function() {
                ngModel.$validate();
            });
        }
    };
}]); 

app.directive('fileModel', ['$parse', function ($parse) {
return {
    restrict: 'A',
    link: function(scope, element, attrs) {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                modelSetter(scope, element[0].files[0]);
            });
        });
    }
};
}]);


var checkLoggedin = function($q, $timeout, $http, $location, $rootScope){
      // Initialize a new promise
      var deferred = $q.defer();
      $http.get('/users/loggedin').success(function(user){
        // Authenticated
        if(user !== '0'){
          //$timeout(deferred.resolve, 0);
        console.log("you are log in " + user);
          deferred.resolve();
             }
        // Not Authenticated
        else {
          $rootScope.message = 'You need to log in.';
          console.log("you are not log in " + user);
          deferred.reject();
         // $timeout(function(){deferred.reject();}, 0);
          $location.url('/login');
        }
      });
      return deferred.promise;
    };