var app =angular.module('shopnxApp', ['ngRoute']);
app.config(function($routeProvider) {
    $routeProvider.when('/login', {
        templateUrl: '/home/pappu/Desktop/mywebsite/js/views/login.html',
        controller: 'indexCtrl'
    }).
        when('/home', {
        templateUrl: '/home/pappu/Desktop/mywebsite/js/views/home.html',
        controller: 'indexCtrl'
    }).
	    when('/cartdetail', {
        templateUrl: '/home/pappu/Desktop/mywebsite/js/views/cartdetail.html',
        controller: 'indexCtrl'
    }).
	    when('/', {
        templateUrl: '/home/pappu/Desktop/mywebsite/index.html',
        controller: 'indexCtrl'
    }).
      otherwise({
        redirectTo: '/' 
      });

     
});
