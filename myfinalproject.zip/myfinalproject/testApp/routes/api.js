var express = require('express');
var router = express.Router();

var mongoose =require('mongoose');
var userModel =require('../modules/usermodel');


router.post('/save' ,function(req ,res){

var user = new userModel();
console.log(req.body);
user.username =req.body.username;
user.name = req.body.name;
user.age = req.body.age;
user.gender = req.body.gender;
user.hobbies = req.body.hobbies;
user.latitude = req.body.latitude;
user.longitude = req.body.longitude;

userModel.findOne({username:req.body.username} ,function(err ,person){
if(err)
{
	console.log(res.send(err));
}
else
{
  
    if(!person)
    {
      user.save(function(err , data){
          if(err)
          {
            
            console.log(res.send(err));
          }
          else
          {
            console.log(data);
            //console.log(data.gender);
            res.send(data);
          }
          });
    }
   
  } 
  
});
});


router.get('/list/:name3', function(req ,res){
  var name2 = req.params.name3;
     userModel.find({hobbies:name2} ,function(err ,person){
    if(err)
    {
  res.send(err);
    }
    else
    {
      console.log(person);
  res.send(person);
    }
  });
});

module.exports=router;