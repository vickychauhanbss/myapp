app.controller("loginctrl" ,function($scope ,$location ,$http, $localStorage ,MarkerCreatorService){

$scope.login = function(){
  $localStorage.name1 =$scope.hobbies;
console.log($localStorage.name1);
console.log($scope.gender);
   //console.log('$scope.name',$scope.name ,'$scope.email',$scope.email);
    $http({
      method: 'POST',
      url: '/api/save',
      data: {username:$scope.username,name:$scope.name, age:$scope.age, gender:$scope.gender, hobbies:$scope.hobbies, latitude:$scope.latitude, longitude:$scope.longitude}
    }).then(function successCallback(response) {
      if(response.data.error){

        $scope.errorr = response.data.error;
        console.log('error',$scope.errorr);
      }else{
        //console.log($scope.gender);
        console.log(response.data);
        $location.path('/list');
      }
    }, function errorCallback(response) {
      console.log('error',response);
    });
  };
});


app.controller("listctrl" ,function($scope ,$location ,$http ,$localStorage){
  angular.element(document).ready(function(){
  var name3=$localStorage.name1;
console.log(name3);
$http({
  method: 'GET',
    url: '/api/list/' + name3,
    }).then(function successCallback(response){
      if(response.data.error){
        $scope.error = response.data.error;
      }else {
        
        $scope.user=response.data;
        $location.path('/list');

                     }
                }
                   ,function errorCallback(response) {
        console.log('error',response);
    }); 
});
  });



