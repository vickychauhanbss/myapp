var app = angular.module("myapp" ,['ngRoute','ngStorage']);
app.config(function($routeProvider){
$routeProvider.when('/login' , {
controller:"loginctrl",
templateUrl:"javascripts/view/login.html"
}).
when('/list' ,{
controller:"listctrl",
templateUrl:"javascripts/view/list.html"
}).
otherwise({
redirectTo:'/login'
});
});



