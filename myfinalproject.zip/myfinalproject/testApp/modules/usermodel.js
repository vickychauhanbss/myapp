var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
    username: {type: String, required:true, unique: true},
    name: {type: String, required:true, unique: true},
    age: String ,
    gender: String,
    hobbies: String,
    latitude: String,
    longitude: String,
   });

var user = mongoose.model("user", userSchema)

module.exports = user;