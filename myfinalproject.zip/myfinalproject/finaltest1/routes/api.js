var express = require('express');
var router = express.Router();
var userModel = require('../model/userModel');


router.post('/userdata' ,function(req ,res){

var user = new userModel();
user.username = req.body.username;
user.name = req.body.name;
user.gender = req.body.gender;
user.hobbies = req.body.hobbies;
user.latitude = req.body.latitude;
user.longitude = req.body.longitude;

userModel.find({} , function(err ,person){
	if(err){
		res.send(err);
	}
	else 
	{
			user.save(function(err , data){
          if(err)
          {
          	res.send(err);
          }
          else
          {
          	res.send(data);
          }
          });
		}
		
	
});
});



module.exports = router;