var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userSchema = new Schema({
    username: String,
	name: String, 
    gender: String,
	hobbies: String,
	latitude: String,
	longitude: String,
});



var user = mongoose.model('user' , userSchema);

module.exports = user;
