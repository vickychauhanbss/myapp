app.controller("myctrl" ,function($scope ,$location){
$scope.save = function(){
		
		$http({
			method: 'POST',
			url: '/api/userdata',
			data: {username:$scope.username,name:$scope.name, gender:$scope.gender , hobbies:$scope.hobbies, latitude:$scope.latitude, longitude:$scope.longitude},
		}).then(function successCallback(response) {
			if(response.data.error){
				$scope.error = response.data.error;
			}else{
				if(response.data.status == true)
				console.log(response.data);
			   $location.path('/list');
			}
		}, function errorCallback(response) {
			console.log('error',response);
		});
	}


});
app.controller("listctrl" ,function($scope){



});
