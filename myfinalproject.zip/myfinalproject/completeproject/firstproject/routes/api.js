var express = require('express');
var router = express.Router();
var userModel = require('../modules/usermodel');
var blogModel = require('../modules/blogmodel');
var contactModel = require('../modules/contactModel');
var mime = require('mime-types')
var multer  = require('multer');
var moment = require('moment');
var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport('smtps://c.vicky1231990@gmail.com:chauhan@smtp.gmail.com');
//var upload = multer({ dest: 'uploads/' });


//***********************uploda image*******************//
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+mime.extension(file.mimetype));
    }
});
var upload = multer({ storage: storage });
//var upload = multer({ dest: 'uploads/' });
var Blogstorage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/blgUploads/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+mime.extension(file.mimetype));
    }
});

//var upload = multer({ storage: storage });
var blogUpload = multer({ storage: Blogstorage });

//******************login router**************************//

router.post('/login', function(req, res) {

var email = req.body.email;
var password=req.body.password; 

userModel.findOne({email:email}, function(err,person){
if(err){
	console.log('err',err);
}
else
{
	if(person.email == email && person.password == password){
			//console.log(req.session.user);
          //req.session.user = person;
          
			//res.redirect('/getAllUser');
			res.send({data:person});
   
		}
		else
		{
			res.send({errer:"password incorrect"});
		}
	}

//res.render('login');

});

  //res.render('login');
});

//***************************register router******************//

router.post('/signup' ,upload.single('file'),function(req ,res){

var user = new userModel();
user.name = req.body.name;
user.email = req.body.email;
user.password = req.body.password;
console.log(req.file);
//user.confirmpassword = req.body.confirmpassword;
user.image = req.file.filename;

userModel.findOne({email:req.body.email} , function(err ,person){
	if(err){
		res.send(err);
	}
	else 
	{
		if(!person)
		{
			user.save(function(err , data){
          if(err)
          {
          	res.send(err);
          }
          else
          {
          	res.send({status:"true",user:data});
          }
          });
		}
		else
		{
           res.send({error:"Email Already Register"});
		}
	}
});

});

router.post('/contact',function(req ,res){

var mailOptions = {
    from: '"Fred Foo 👥" <foo@blurdybloop.com>', // sender address 
    to: 'sunpreetckd@gmail.com', // list of receivers 
    subject: 'Hello ✔', // Subject line 
    text: 'Hello world 🐴', // plaintext body 
    html: '<b>Hello world 🐴</b>' // html body 
};
 
// send mail with defined transport object 
transporter.sendMail(mailOptions, function(error, info){
    if(error){
        return console.log(error);
    }
    console.log('Message sent: ' + info.response);
});
});

//*********************addblog page************************//

router.post('/addblog' , blogUpload.single('file'),function(req ,res){
	console.log(req.body);
var blog = new blogModel();
blog.title=req.body.title;
blog.content=req.body.content;
blog.file=req.file.filename;
blog.tags=req.body.tags;
// blog.uid = req.body.uid;
// blog.createdbydate = moment().format();
blog.save(function(err , data){
          if(err)
          {
          	res.send(err);
          }
          else
          {
          	console.log(data);
          	res.send(data);
          }
          });
		
	
});
//***************************list route************//

router.get('/list', function(req ,res){
     blogModel.find({} ,function(err ,person){
    if(err)
    {
	res.send(err);
    }
    else
    {
	res.send(person);
    }
  });
});

//***************delete blog data*************************//

router.delete('/del/:id', function(req, res)
 { 
blogModel.findById(req.params.id, function(err ,person)
{
person.remove(function(err , person)
{
res.send(person);
//res.redirect('/getAllUser');
    });
    });
});

//******************view single blog*********************//

router.get('/view/:id', function(req ,res){
     blogModel.find(req.params.id ,function(err ,person){
    if(err)
    {
  res.send(err);
    }
    else
    {
  res.send(person);
    }
  });
});

//*****************Edit blog************************//

router.get('/edit/:id', function(req, res) { 
    blogModel.findById(req.params.id, function(err ,person)
  {
    if(err)
      {
      res.send(err);
    }
    else
    {
    res.send(person);
    }
  });
});

//********************* update api****************//

router.post('/update/:id' ,function(req,res){
  var uid =req.params.id;
blogModel.findById(uid,function(err ,blog){

    blog.title = req.body.title;
    blog.content  = req.body.content;
    blog.tags  = req.body.tags;
    //blog.images  = req.file.filename;
    blog.save( function ( err, data ){
      if(err){
        res.json(err);
      }else{
    // req.session.user=person;
      //res.redirect( '/list');
      res.send(data)
  }
    });

});
});






//*************************profile route**************//
router.post('/profile', function(req ,res){
     userModel.find({} ,function(err ,person){
    if(err)
    {
    res.send(err);
    }
    else
    {
    res.send(person);
    }
  });
});



module.exports = router;