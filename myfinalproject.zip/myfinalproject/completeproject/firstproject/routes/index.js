var express = require('express');
var multer  =  require('multer');
var router = express.Router();
var usermodule = require('../modules/usermodel');

/* GET home page. */
router.get('/*', function(req, res, next) {
  res.render('index', { title: 'Express' });
});







