var mongoose = require('mongoose')
var Schema = mongoose.Schema;

var blogSchema = new Schema({
    title: String,
    content: String,
    file: String,
    tags: String,
});



var Blog = mongoose.model('blog' , blogSchema);

module.exports = Blog;


