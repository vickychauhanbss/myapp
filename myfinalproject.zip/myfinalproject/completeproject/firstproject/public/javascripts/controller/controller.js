app.controller("controller1" , function($scope ,$location, $http , auth,$localStorage, $routeParams){
	$scope.login = function(){
		auth.setTlogIn($scope.email,$scope.password);
	}
	$scope.userdata=$localStorage.myuserdata;
	console.log($scope.userdata);
	 // 	$http({
		//   method: 'POST',
		//   url: '/api/login',
		//   data: {email:$scope.email, password:$scope.password},
		// }).then(function successCallback(response) {
		// 	if(response.data.error){
		// 		$scope.error = response.data.error;
		// 	}else if(response.data.status==true){
		// 		//console.log(response.data);
		// 		$location.path('/home');
	 //      }
		//    // console.log(response);
		// }, function errorCallback(response) {
		//     console.log('error',response);
		// });
	 

	 $scope.signuppage=function(){
	 	$location.path('/register');
	 }


	$scope.signup = function(){
      var file = $scope.myform.user.myFile;
      var uploadUrl = "api/signup";
        var fd = new FormData();
        fd.append('name',$scope.myform.user.name);
        fd.append('email',$scope.myform.user.email);
        fd.append('password',$scope.myform.user.password);
        fd.append('file', file);
        //JSON.stringify({name:$scope.registration.user.name,email:$scope.registration.user.email,password:$scope.registration.user.password, file:file})
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success( function (response){
          console.log("success!!",response);
          $scope.user=response.person;
          //console.log($scope.user);
          $location.path("/login");
        })
        .error(function(){
          console.log("error!!");
        });
    };


//*************profile page**************//



});


app.controller("controller2" , function($scope, $http){
// $scope.msg = "this is home pge";

angular.element(document).ready(function(){
	$scope.error="";
$http({
	method: 'GET',
    url: '/api/list/',
    }).then(function successCallback(response){
			if(response.data.error){
				$scope.error = response.data.error;
			}else {
				
				$scope.blog=response.data;
				         $scope.currentPage = 1;
	$scope.totalItems = $scope.blog.length;
	$scope.entryLimit = 4; 
	$scope.noOfpages = Math.ceil($scope.totalItems / $scope.entryLimit);

                     }
                }
                   ,function errorCallback(response) {
		    console.log('error',response);
		}); 
});
});


app.controller("contactCtrl" , function($scope){

});

//**************************blog add************************//

app.controller("addctrl" , function($scope ,$location, $http ,$routeParams,$localStorage)
 {
 	$scope.user2=$localStorage.user1
 	$scope.addblog = function(){
    var file = $scope.blogForm.user.myFile;
    var uploadUrl = "api/addblog";
 	 	var fd = new FormData();
 		fd.append('title',$scope.blogForm.user.title);
        fd.append('content',$scope.blogForm.user.content);
        fd.append('tags',$scope.blogForm.user.tags);
        fd.append('file', file);
        console.log(fd);
  $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function (response){
             //console.log(response);
          //console.log(response);
          $location.path("/list");
        })
        .error(function(){
          console.log("error!!");
        }); 
		
 	 }

	

//**************************show data on list.html****************************//

angular.element(document).ready(function(){
	$scope.error="";
$http({
	method: 'GET',
    url: '/api/list/',
    }).then(function successCallback(response){
			if(response.data.error){
				$scope.error = response.data.error;
			}else {
				
				$scope.user=response.data;
				
                     }
                }
                   ,function errorCallback(response) {
		    console.log('error',response);
		}); 
});

//*******************list data delete ********************//

$scope.delete =function(id){
 $scope.error="";
 $http({
	method: 'DELETE',
    url: '/api/del/' +id,
    }).then(function successCallback(response){
			if(response.data.error){
				$scope.error = response.data.error;
			}else {
				
				$scope.user.forEach(function(value ,index)
				{
					if(value._id==id){
						$scope.user.splice(index,1);
					}
				});
                     
                     }
                },function errorCallback(response) {
		    console.log('error',response);
	 });
    };

//****** show single blog on  view.html ***********//

angular.element(document).ready(function(){
	$scope.error="";
	 if($routeParams.id !=undefined){
$http({
	method: 'GET',
    url: '/api/view/'+$routeParams.id,
    }).then(function successCallback(response) {
			if(response.data.error){
				$scope.error = response.data.error;
			}else {
				
				$scope.user=response.data;
				console.log($scope.user);
     					$scope.user.forEach(function(value ,index){
						if(value._id == $routeParams.id){
							$scope.viewdata = value;
							console.log($scope.viewdata);
						}
					});
				
				}
				
		    },function errorCallback(response) {
		    console.log('error',response);
		}); 
}
    $scope.viewUser =function(id){
	$location.path('/'+id );
};
});

//***************Edit blog****************************//

$scope.editBlog = function(id) {
$http({
    method:"get",
    url:'api/edit/'+id,
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.user=response.data;

        $localStorage.user1=$scope.user;
       console.log( $scope.user);
        $location.path('/editBlog');
      }
      //console.log(response);
    }, function errorCallback(response){
      console.log('error',response);
    });
}


//**************** Update blog *****************//
$scope.UpdateBlog = function(id) {
$http({
    method:"POST",
    url:'/api/update/'+id,
    data:{title:$scope.user2.title,content:$scope.user2.content,tags:$scope.user2.tags}
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog=response.data;
        //console.log( $scope.updateValue)
        $location.path('/list');
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });
}
});


//****************contact controller ****************//


app.controller("contactCtrl" , function($scope ,$location, $http ,$routeParams,$localStorage)
 {
$scope.contact = function(){
		
	 	$http({
		  method: 'POST',
		  url: '/api/contact',
		  data: {name:$scope.name,email:$scope.email, message:$scope.message},
		}).then(function successCallback(response) {
			if(response.data.error){
				$scope.error = response.data.error;
			}else if(response.data.status==true){
				console.log(response.data);
				//$location.path('/contact');
	      }
		   // console.log(response);
		}, function errorCallback(response) {
		    console.log('error',response);
		});
	 }
});


	