var app = angular.module("myapp" ,['ngRoute','ngMessages','ngStorage','ui.bootstrap']);
app.config(function($routeProvider,$locationProvider){
$routeProvider. when('/home' , {
controller:"controller2",
templateUrl:"javascripts/views/home.html"
}).
when('/login' ,{
controller:"controller1",
templateUrl:"javascripts/views/login.html"
}).
when('/register' ,{
controller:"controller1",
templateUrl:"javascripts/views/register.html"
}).
when('/contact' ,{
controller:"contactCtrl",
templateUrl:"javascripts/views/contact.html",
resolve: {
    auth:function(auth,$location){
        if(auth.isLoggin()){
            $location.path('/contact')
        }else{
            alert("plz login");
             $location.path('/login')
        }

    }
}
}).
when('/addblog' ,{
controller:"addctrl",
templateUrl:"javascripts/views/add.html",
resolve: {
    auth:function(auth,$location){
        if(auth.isLoggin()){
            $location.path('/addblog')
        }else{
            alert("plz login");
             $location.path('/login')
        }

    }
}
}).
when('/list' ,{
controller:"addctrl",
templateUrl:"javascripts/views/list.html",
resolve: {
    auth:function(auth,$location){
        if(auth.isLoggin()){
            $location.path('/list')
        }else{
            alert("plz login");
             $location.path('/login')
        }

    }
}
}).
when('/editBlog' ,{
controller:"addctrl",
templateUrl:"javascripts/views/edit.html"
//resolve: {
//     auth:function(auth,$location){
//         if(auth.isLoggin()){
//             $location.path('/edit')
//         }else{
//             alert("plz login");
//              $location.path('/login')
//         }

//     }
// }
}).
when('/profile' ,{
controller:"controller1",
templateUrl:"javascripts/views/profile.html"
}).
when('/:id' ,{
controller:"addctrl",
templateUrl:"javascripts/views/view.html"
}).
otherwise({
redirectTo:'/home'
});
$locationProvider.html5Mode({
      enabled: true,
     requireBase: false
      });
});

 app .directive('compareTo', [function() {
    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function(scope, element, attributes, ngModel) {
             
            ngModel.$validators.compareTo = function(modelValue) {
                return modelValue == scope.otherModelValue;
            };
 
            scope.$watch("otherModelValue", function() {
                ngModel.$validate();
            });
        }
    };
}]); 

app.directive('fileModel', ['$parse', function ($parse) {
return {
    restrict: 'A',
    link: function(scope, element, attrs) {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                modelSetter(scope, element[0].files[0]);
            });
        });
    }
};
}]);
    app.filter('startFrom', function () {
    return function (input, start) {
        if (input) {
            start = +start;
            return input.slice(start);
        }
        return [];
    };
});